package org.contacts.proxy;

import java.util.List;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static javax.ws.rs.core.MediaType.TEXT_PLAIN;

public class ContactBookProxy implements ContactBook {

	private static final String RESOURCE_URI = "http://localhost:8080/contactbook/rest/contacts";
	private final WebTarget webTarget;

	public ContactBookProxy() {
		webTarget = ClientBuilder.newClient().target(RESOURCE_URI);
	}

	@Override
	public Contact findContact(long id) throws NotFoundException {
		Response response = webTarget.path(String.valueOf(id)).request(APPLICATION_XML).get();
		if (response.getStatus() != Status.OK.getStatusCode()) {
			if (response.getStatus() == Status.NOT_FOUND.getStatusCode()) {
				throw new NotFoundException(response.readEntity(String.class));
			} else {
				throw new WebApplicationException(response);
			}
		}
		return response.readEntity(Contact.class);
	}

	@Override
	public List<Contact> searchContacts(String name) {
		Response response = webTarget.queryParam("name", name).register(GZIPReaderInterceptor.class)
				.request(APPLICATION_XML).acceptEncoding("gzip").get();
		if (response.getStatus() != Status.OK.getStatusCode()) {
			throw new WebApplicationException(response);
		}
		return response.readEntity(new GenericType<List<Contact>>() {
		});
	}

	@Override
	public long createContact(String name, String phone, String email) {
		Contact contact = new Contact(name, phone, email);
		Response response = webTarget.request(TEXT_PLAIN).post(Entity.xml(contact));
		if (response.getStatus() != Status.CREATED.getStatusCode()) {
			throw new WebApplicationException(response);
		}
		return response.readEntity(Long.class);
	}

	@Override
	public void updateContact(Contact contact) throws NotFoundException {
		Response response = webTarget.path(String.valueOf(contact.getId())).request().put(Entity.xml(contact));
		if (response.getStatus() != Status.NO_CONTENT.getStatusCode()) {
			throw new WebApplicationException(response);
		}
	}

	@Override
	public void deleteContact(long id) {
		Response response = webTarget.path(String.valueOf(id)).request().delete();
		if (response.getStatus() != Status.NO_CONTENT.getStatusCode()) {
			throw new WebApplicationException(response);
		}
	}
}
