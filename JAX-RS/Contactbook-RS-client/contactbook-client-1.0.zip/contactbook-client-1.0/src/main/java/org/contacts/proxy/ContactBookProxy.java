package org.contacts.proxy;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;

public class ContactBookProxy implements ContactBook {

	private static final String ENDPOINT_ADDRESS = "http://localhost:8080/contactbook/soap";
	private static final String TARGET_NAMESPACE = "http://example.org/contactbook";

	private final SOAPFactory soapFactory;
	private final MessageFactory messageFactory;
	private final SOAPConnection connection;

	public ContactBookProxy() {
		try {
			soapFactory = SOAPFactory.newInstance();
			messageFactory = MessageFactory.newInstance();
			connection = SOAPConnectionFactory.newInstance().createConnection();
		} catch (SOAPException ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	public Contact findContact(long id) throws NotFoundException {
		try {
			SOAPMessage request = messageFactory.createMessage();
			SOAPElement bodyElement = request.getSOAPBody().addChildElement("findContact", "tns", TARGET_NAMESPACE);
			bodyElement.addChildElement("id").addTextNode(String.valueOf(id));
			SOAPBody responseBody = connection.call(request, ENDPOINT_ADDRESS).getSOAPBody();
			if (responseBody.hasFault()) {
				SOAPFault fault = responseBody.getFault();
				if (fault.hasDetail() && fault.getDetail().getFirstChild().getLocalName().equals("NotFoundFault")) {
					throw new NotFoundException(fault.getFaultString());
				} else {
					throw new RuntimeException(fault.getFaultString());
				}
			}
			bodyElement = (SOAPElement) responseBody.getFirstChild();
			SOAPElement contactElement = (SOAPElement) bodyElement.getFirstChild();
			return convert(contactElement);
		} catch (SOAPException ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	public List<Contact> searchContacts(String name) {
		try {
			SOAPMessage request = messageFactory.createMessage();
			SOAPElement bodyElement = request.getSOAPBody().addChildElement("searchContacts", "tns", TARGET_NAMESPACE);
			bodyElement.addChildElement("name").addTextNode(name);
			SOAPBody responseBody = connection.call(request, ENDPOINT_ADDRESS).getSOAPBody();
			if (responseBody.hasFault()) {
				throw new RuntimeException(responseBody.getFault().getFaultString());
			}
			bodyElement = (SOAPElement) responseBody.getFirstChild();
			List<Contact> contacts = new ArrayList<>();
			for (Iterator<SOAPElement> iter = bodyElement.getChildElements(); iter.hasNext();) {
				contacts.add(convert(iter.next()));
			}
			return contacts;
		} catch (SOAPException ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	public long createContact(String name, String phone, String email) {
		try {
			SOAPMessage request = messageFactory.createMessage();
			SOAPElement bodyElement = request.getSOAPBody().addChildElement("createContact", "tns", TARGET_NAMESPACE);
			bodyElement.addChildElement("name").addTextNode(name);
			if (phone != null) {
				bodyElement.addChildElement("phone").addTextNode(phone);
			}
			if (email != null) {
				bodyElement.addChildElement("email").addTextNode(email);
			}
			SOAPBody responseBody = connection.call(request, ENDPOINT_ADDRESS).getSOAPBody();
			if (responseBody.hasFault()) {
				throw new RuntimeException(responseBody.getFault().getFaultString());
			}
			bodyElement = (SOAPElement) responseBody.getFirstChild();
			SOAPElement idElement = (SOAPElement) bodyElement.getFirstChild();
			return Long.parseLong(idElement.getValue());
		} catch (SOAPException ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	public void updateContact(Contact contact) throws NotFoundException {
		try {
			SOAPMessage request = messageFactory.createMessage();
			SOAPElement bodyElement = request.getSOAPBody().addChildElement("updateContact", "tns", TARGET_NAMESPACE);
			SOAPElement contactElement = bodyElement.addChildElement("contact");
			contactElement.setAttribute("id", String.valueOf(contact.getId()));
			contactElement.addChildElement("name").addTextNode(contact.getName());
			if (contact.getPhone() != null) {
				contactElement.addChildElement("phone").addTextNode(contact.getPhone());
			}
			if (contact.getEmail() != null) {
				contactElement.addChildElement("email").addTextNode(contact.getEmail());
			}
			SOAPBody responseBody = connection.call(request, ENDPOINT_ADDRESS).getSOAPBody();
			if (responseBody.hasFault()) {
				SOAPFault fault = responseBody.getFault();
				if (fault.getDetail().getFirstChild().getNodeName().equals("NotFoundFault")) {
					throw new NotFoundException(fault.getFaultString());
				} else {
					throw new RuntimeException(fault.getFaultString());
				}
			}
		} catch (SOAPException ex) {
			throw new RuntimeException(ex);
		}
	}

	@Override
	public void deleteContact(long id) {
		try {
			SOAPMessage request = messageFactory.createMessage();
			SOAPElement bodyElement = request.getSOAPBody().addChildElement("deleteContact", "tns", TARGET_NAMESPACE);
			bodyElement.addChildElement("id").addTextNode(String.valueOf(id));
			connection.call(request, ENDPOINT_ADDRESS).getSOAPBody();
		} catch (SOAPException ex) {
			throw new RuntimeException(ex);
		}
	}

	private Contact convert(SOAPElement element) {
		Contact contact = new Contact();
		contact.setId(Long.parseLong(element.getAttribute("id")));
		Iterator<SOAPElement> iter = element.getChildElements();
		while (iter.hasNext()) {
			SOAPElement childElement = iter.next();
			switch (childElement.getTagName()) {
				case "name":
					contact.setName(childElement.getValue());
					break;
				case "phone":
					contact.setPhone(childElement.getValue());
					break;
				case "email":
					contact.setEmail(childElement.getValue());
					break;
			}
		}
		return contact;
	}
}
