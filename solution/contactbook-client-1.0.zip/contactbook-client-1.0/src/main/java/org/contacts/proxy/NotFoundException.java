package org.contacts.proxy;

public class NotFoundException extends Exception {

	public NotFoundException(String message) {
		super(message);
	}
}
