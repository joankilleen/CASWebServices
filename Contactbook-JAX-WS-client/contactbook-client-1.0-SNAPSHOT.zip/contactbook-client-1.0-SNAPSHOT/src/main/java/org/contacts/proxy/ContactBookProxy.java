package org.contacts.proxy;

import java.util.List;

public class ContactBookProxy implements ContactBook {

	@Override
	public Contact findContact(long id) throws NotFoundException {
		throw new UnsupportedOperationException();
	}

	@Override
	public List<Contact> searchContacts(String name) {
		throw new UnsupportedOperationException();
	}

	@Override
	public long createContact(String name, String phone, String email) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void updateContact(Contact contact) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void deleteContact(long id) {
		throw new UnsupportedOperationException();
	}
}
